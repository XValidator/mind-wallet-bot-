
# 🔐 Telegram Bot Token
BOT_TOKEN = "7768812382:AAFprXQTlWGT7E_IHDdSQg41ePfpUERUjXc"

# 🌐 RPC для Binance Smart Chain
BSC_RPC = "https://bsc-dataseed.binance.org/"

# 🧠 Контракт токена MIND (BEP-20)
MIND_CONTRACT = "0xEfC814a4C676a7314a13954e283de6cef597e6b2"
MIND_DECIMALS = 18
MIND_SYMBOL = "MIND"

# 🔎 API ключі (опціонально — для історії транзакцій або ціни)
BSCSCAN_API_KEY = ""
COINGECKO_API_KEY = ""
